# Intro

## N-words vs. NPIs

- many languages distinguish

1) syntactically negative dependentent expressions: **n-words**

2) semantically negative dependent expressions: **N(egative) P(olarity) I(tems)**

\begin{example}
\xgll Dhen idhe **kanenan** o Janis. \xgle
not saw NPI-person the John\xgle
\glt 'John didn't see anybody'
\glend
\end{example}
